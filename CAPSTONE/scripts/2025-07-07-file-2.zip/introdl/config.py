# Configuration file for introdl package
# Add any shared settings or constants here
MODEL_VERSION = '1.0'
